import 'package:flutter/material.dart';
import 'package:flutterapp/hildan_menumakananapp/generatediphone83widget/GeneratedIPhone83Widget.dart';
import 'package:flutterapp/hildan_menumakananapp/generatediphone82widget/GeneratedIPhone82Widget.dart';
import 'package:flutterapp/hildan_menumakananapp/generatediphone81widget/GeneratedIPhone81Widget.dart';

void main() {
  runApp(hildan_menumakananApp());
}

class hildan_menumakananApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/GeneratedIPhone81Widget',
      routes: {
        '/GeneratedIPhone83Widget': (context) => GeneratedIPhone83Widget(),
        '/GeneratedIPhone82Widget': (context) => GeneratedIPhone82Widget(),
        '/GeneratedIPhone81Widget': (context) => GeneratedIPhone81Widget(),
      },
    );
  }
}
